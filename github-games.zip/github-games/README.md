## Welcome to GitHub Games

A project based learning activity for people who are getting started with Git and GitHub.

You can play the game at: https://githubschool.github.io/github-games/

>> _*SUPPORTED BROWSERS*: Chrome, Firefox, Safari, Opera and IE9+_

This fun open source game was cloned from: https://github.com/jakesgordon/javascript-tetris
